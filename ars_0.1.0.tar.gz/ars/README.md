# ars
An R package to perform adaptive-rejection sampling

Developed by Vaibhav Ramamoorthy, Colin Kou, Brandon Mannion, and Jonathan Lee for Stat 243, taught by Chris Paciorek.
