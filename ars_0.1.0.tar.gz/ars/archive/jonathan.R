h <- function(x) {
  return(-x^2)
}

x <- -5:5

j<-1


x[2]